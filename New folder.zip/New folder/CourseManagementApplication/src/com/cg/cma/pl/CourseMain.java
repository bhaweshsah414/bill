package com.cg.cma.pl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.cg.cma.dto.Course;
import com.cg.cma.exceptions.CourseException;
import com.cg.cma.service.CourseService;
import com.cg.cma.service.CourseServiceImpl;

public class CourseMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		CourseService cser = new CourseServiceImpl();
		do {
			System.out.println("Menu");
			System.out.println("1. Show all Courses");
			System.out.println("2. Add new Course");
			System.out.println("3. Update a Course");
			System.out.println("4. Delete a Course");
			System.out.println("5. Exit");
			System.out.println("Enter your choice :");
			int choice=sc.nextInt();
			switch(choice) {
			case 1: 
				try {
					List<Course> clist = cser.getAllCourses();
					for(Course c:clist) {
						System.out.println(c);
					}
				} catch (CourseException e) {
					System.err.println(e.getMessage());
				}
				break;
			case 2:
				Course c = new Course();
				System.out.println("Enter course title:");
				c.setCourseTitle(sc.next());
				System.out.println("Enter course duration :");
				c.setDuration(sc.nextInt());
				System.out.println("Enter course fees :");
				c.setFees(sc.nextDouble());
				try {
					if(cser.validate(c)) {
						long cid = cser.inserCourse(c);
						System.out.println("Course added with id "+cid);
					}
				} catch (CourseException e) {
					System.err.println(e.getMessage());
				}
				break;
			case 3: System.out.println("Not implemented yet");
				break;
			case 4:System.out.println("Not implemented yet");
				break;
			case 5: 
					System.out.println("Thank you");
					System.exit(0);
			default : System.out.println("Invalid choice");
			}
		}while(true);
	}
}
