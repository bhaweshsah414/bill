package com.cg.cra.dao;

import java.util.List;

import com.cg.cra.dto.Course;
import com.cg.cra.dto.Registration;
import com.cg.cra.exceptions.RegistrationException;

public interface RegistrationDao {
	List<Course> getAllCourses() throws RegistrationException;
	long registerCourse(Registration registration) throws RegistrationException;
	boolean validateCourseId(long courseId) throws RegistrationException;
}
