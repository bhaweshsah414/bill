import { Injectable } from '@angular/core';

import { Customer } from './customer';
import { HttpClientModule } from '@angular/common/http'; 
import { HttpModule } from '@angular/http';
import {Http} from '@angular/http';


import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';







//const headers= new HttpHeaders({ 'Content-Type':'application/json'});

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
 path = '../assets/customer.json';
 constructor(private http:HttpClient) { 
  


	}
	getCustomer():Observable<Customer[]>{
		return this.http.get<Customer[]>(this.path);
	}
    

  }






