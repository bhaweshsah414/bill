import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';
import { Customer } from '../customer'



@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css'],
  providers: [CustomerService]
})
export class CustomersComponent implements OnInit {
  customer:Customer[];

constructor(private service: CustomerService, private router:Router ){
	}
  ngOnInit() {
		this.service.getCustomer().subscribe(z=> this.customer = z);
	}

 getCustomerById(customerId){
		
		this.router.navigate(["/customer", customerId]);
	}
	}
 
 







