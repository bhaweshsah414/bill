import { Component, OnInit } from '@angular/core';
import { MerchantService } from '../merchant-service.service';
import { Router } from '@angular/router';
import { Merchant } from '../merchant'

@Component({
  selector: 'app-merchant',
  templateUrl: './merchant.component.html',
  styleUrls: ['./merchant.component.css'],
  providers: [MerchantService]
})
export class MerchantComponent implements OnInit {
	
	merchants: Merchant[];
	ngOnInit() {
		this.service.getData().subscribe(d => this.merchants = d);
	}
	constructor(private service: MerchantService, private router:Router ){
	}

	
	getDataById(merchantId){
		
		this.router.navigate(["/merchant", merchantId]);
	}
	
}
