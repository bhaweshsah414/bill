
import { Injectable } from '@angular/core';
import { Product } from './product';

import { HttpClientModule } from '@angular/common/http'; 
import { HttpModule } from '@angular/http';
import {Http} from '@angular/http';


import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';



//const headers= new HttpHeaders({ 'Content-Type':'application/json'});


@Injectable({
  providedIn: 'root'
})
export class ProductService {
	path = '../assets/product.json';
	
	
	constructor(private http:HttpClient) { 
	
	}
	getProduct():Observable<Product[]>{
		return this.http.get<Product[]>(this.path);
	}

}







