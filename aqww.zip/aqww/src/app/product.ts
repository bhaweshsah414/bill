
export class Product{
   
    productId:number;
    productName:string;
	productPrice:number;
	productQuantity:number;
    discountOffered:number;
    productCategory:string;
	productType:string;
	productBrand:string;
    productModel:string;
    productFeatures:string;
    productRating:number;
    productFeedback:string;
    
   
}