import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product-service.service';
import { Router } from '@angular/router';
import { Product } from '../product'



@Component({
  selector: 'app-merchant',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
  providers: [ProductService]
})
export class ProductComponent implements OnInit {
	
	products: Product[];
	ngOnInit() {
		this.service.getProduct().subscribe(a => this.products = a);
	}
	constructor(private service: ProductService, private router:Router ){
	}

	
	getProductById(productId){
		
		this.router.navigate(["/product", productId]);
	}
	}