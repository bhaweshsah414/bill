import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule } from '@angular/forms';
import {RouterModule, Routes } from '@angular/router';
import {HttpClientModule}   from '@angular/common/http';
import { AppComponent } from './app.component';
import { EmployeesComponent } from './employees/employees.component';
import { EmployeeComponent } from './employee/employee.component';


const routes: Routes = [
{path: 'employees', component: EmployeesComponent},
{path: 'employee/:id', component: EmployeeComponent},
{path: '', component: EmployeesComponent},
];

@NgModule({
  declarations: [
    AppComponent,
    EmployeesComponent,
    EmployeeComponent,
    
  ],
  imports: [
    BrowserModule,HttpClientModule, FormsModule, RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

