import { Component, OnInit } from '@angular/core';
import { DataService } from '../employee.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-employees',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers: [DataService]
})
export class EmployeeComponent implements OnInit {
   
  id:number;
  constructor( private route: ActivatedRoute, private service: DataService ) { }
  
  emp:any;
  ngOnInit() {
  this.id = this.route.snapshot.params['id'];
  
  this.service.getDataById(this.id).subscribe(d => this.emp = d);
  }
  
}

